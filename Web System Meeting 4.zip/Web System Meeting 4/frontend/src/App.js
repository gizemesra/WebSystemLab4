import React, { useState, useEffect } from 'react';
import './App.css';

const API_BASE = 'http://localhost:3000';

function App() {
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [activeTab, setActiveTab] = useState('students');
  const [editingStudent, setEditingStudent] = useState(null);
  const [editingCourse, setEditingCourse] = useState(null);

  useEffect(() => {
    fetchStudents();
    fetchCourses();
  }, []);

  const fetchStudents = async () => {
    const response = await fetch(`${API_BASE}/students`);
    const data = await response.json();
    setStudents(data);
  };

  const fetchCourses = async () => {
    const response = await fetch(`${API_BASE}/courses`);
    const data = await response.json();
    setCourses(data);
  };

  const handleAddStudent = async (student) => {
    await fetch(`${API_BASE}/students`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student)
    });
    fetchStudents();
  };

  const handleUpdateStudent = async (id, student) => {
    await fetch(`${API_BASE}/students/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student)
    });
    fetchStudents();
    setEditingStudent(null);
  };

  const handleDeleteStudent = async (id) => {
    await fetch(`${API_BASE}/students/${id}`, { method: 'DELETE' });
    fetchStudents();
  };

  const handleAddCourse = async (course) => {
    await fetch(`${API_BASE}/courses`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(course)
    });
    fetchCourses();
  };

  const handleUpdateCourse = async (id, course) => {
    await fetch(`${API_BASE}/courses/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(course)
    });
    fetchCourses();
    setEditingCourse(null);
  };

  const handleDeleteCourse = async (id) => {
    await fetch(`${API_BASE}/courses/${id}`, { method: 'DELETE' });
    fetchCourses();
  };

  return (
    <div className="App">
      <h1>Student Management System</h1>
      <div className="tabs">
        <button className={activeTab === 'students' ? 'active' : ''} onClick={() => setActiveTab('students')}>Students</button>
        <button className={activeTab === 'courses' ? 'active' : ''} onClick={() => setActiveTab('courses')}>Courses</button>
      </div>
      {activeTab === 'students' && (
        <StudentSection
          students={students}
          courses={courses}
          onAdd={handleAddStudent}
          onUpdate={handleUpdateStudent}
          onDelete={handleDeleteStudent}
          editing={editingStudent}
          setEditing={setEditingStudent}
        />
      )}
      {activeTab === 'courses' && (
        <CourseSection
          courses={courses}
          onAdd={handleAddCourse}
          onUpdate={handleUpdateCourse}
          onDelete={handleDeleteCourse}
          editing={editingCourse}
          setEditing={setEditingCourse}
        />
      )}
    </div>
  );
}

function StudentSection({ students, courses, onAdd, onUpdate, onDelete, editing, setEditing }) {
  const [form, setForm] = useState({ name: '', email: '', courseIds: [] });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editing) {
      onUpdate(editing.id, form);
    } else {
      onAdd(form);
    }
    setForm({ name: '', email: '', courseIds: [] });
  };

  const startEdit = (student) => {
    setEditing(student);
    setForm({ name: student.name, email: student.email, courseIds: student.courseIds });
  };

  return (
    <div>
      <h2>Students</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
        />
        <select
          multiple
          value={form.courseIds}
          onChange={(e) => setForm({ ...form, courseIds: Array.from(e.target.selectedOptions, o => parseInt(o.value)) })}
        >
          {courses.map(course => (
            <option key={course.id} value={course.id}>{course.name}</option>
          ))}
        </select>
        <button type="submit">{editing ? 'Update' : 'Add'} Student</button>
        {editing && <button type="button" className="cancel" onClick={() => setEditing(null)}>Cancel</button>}
      </form>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            <div className="info">
              <h3>{student.name}</h3>
              <p>{student.email} - Courses: {student.courseIds.map(id => courses.find(c => c.id === id)?.name).join(', ')}</p>
            </div>
            <div>
              <button className="edit" onClick={() => startEdit(student)}>Edit</button>
              <button className="delete" onClick={() => onDelete(student.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CourseSection({ courses, onAdd, onUpdate, onDelete, editing, setEditing }) {
  const [form, setForm] = useState({ name: '', description: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editing) {
      onUpdate(editing.id, form);
    } else {
      onAdd(form);
    }
    setForm({ name: '', description: '' });
  };

  const startEdit = (course) => {
    setEditing(course);
    setForm({ name: course.name, description: course.description });
  };

  return (
    <div>
      <h2>Courses</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          required
        />
        <button type="submit">{editing ? 'Update' : 'Add'} Course</button>
        {editing && <button type="button" className="cancel" onClick={() => setEditing(null)}>Cancel</button>}
      </form>
      <ul>
        {courses.map(course => (
          <li key={course.id}>
            <div className="info">
              <h3>{course.name}</h3>
              <p>{course.description}</p>
            </div>
            <div>
              <button className="edit" onClick={() => startEdit(course)}>Edit</button>
              <button className="delete" onClick={() => onDelete(course.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
