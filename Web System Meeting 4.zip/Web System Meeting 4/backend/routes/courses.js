const express = require('express');
const Joi = require('joi');
const data = require('../data');
const router = express.Router();

// Validation schemas
const courseSchema = Joi.object({
  name: Joi.string().required(),
  description: Joi.string().required()
});

// GET /courses
router.get('/', (req, res) => {
  try {
    res.status(200).json(data.courses);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /courses/:id
router.get('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const course = data.courses.find(c => c.id === id);
    if (!course) {
      return res.status(404).json({ error: 'Course not found' });
    }
    res.status(200).json(course);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /courses
router.post('/', (req, res) => {
  try {
    const { error, value } = courseSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    const newId = data.courses.length > 0 ? Math.max(...data.courses.map(c => c.id)) + 1 : 1;
    const newCourse = { id: newId, ...value };
    data.courses = [...data.courses, newCourse];
    res.status(200).json(newCourse);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PUT /courses/:id
router.put('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { error, value } = courseSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    const index = data.courses.findIndex(c => c.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Course not found' });
    }
    data.courses = data.courses.map(c => c.id === id ? { id, ...value } : c);
    res.status(200).json(data.courses[index]);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /courses/:id
router.delete('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const index = data.courses.findIndex(c => c.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Course not found' });
    }
    data.courses = data.courses.filter(c => c.id !== id);
    res.status(200).json({ message: 'Course deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;