const express = require('express');
const Joi = require('joi');
const data = require('../data');
const router = express.Router();

// Validation schemas
const studentSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  courseIds: Joi.array().items(Joi.number()).required()
});

// GET /students
router.get('/', (req, res) => {
  try {
    res.status(200).json(data.students);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /students/:id
router.get('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const student = data.students.find(s => s.id === id);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.status(200).json(student);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /students
router.post('/', (req, res) => {
  try {
    const { error, value } = studentSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    const newId = data.students.length > 0 ? Math.max(...data.students.map(s => s.id)) + 1 : 1;
    const newStudent = { id: newId, ...value };
    data.students = [...data.students, newStudent];
    res.status(200).json(newStudent);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PUT /students/:id
router.put('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { error, value } = studentSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    const index = data.students.findIndex(s => s.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Student not found' });
    }
    data.students = data.students.map(s => s.id === id ? { id, ...value } : s);
    res.status(200).json(data.students[index]);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /students/:id
router.delete('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const index = data.students.findIndex(s => s.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Student not found' });
    }
    data.students = data.students.filter(s => s.id !== id);
    res.status(200).json({ message: 'Student deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;