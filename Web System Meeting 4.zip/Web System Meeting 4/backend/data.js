const fs = require('fs');
const path = require('path');

const studentsFile = path.join(__dirname, 'students.json');
const coursesFile = path.join(__dirname, 'courses.json');

// Helper functions to read/write JSON
const readJSON = (file) => {
  try {
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
};

const writeJSON = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Initialize data
let students = readJSON(studentsFile);
let courses = readJSON(coursesFile);

// Export with getters/setters to persist changes
module.exports = {
  get students() {
    return students;
  },
  set students(value) {
    students = value;
    writeJSON(studentsFile, students);
  },
  get courses() {
    return courses;
  },
  set courses(value) {
    courses = value;
    writeJSON(coursesFile, courses);
  }
};